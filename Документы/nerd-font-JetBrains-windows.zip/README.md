<h1 align="center">Welcome to nerd-font-JetBrains-windows 👋</h1>
<p>
  <a href="LICENSE" target="_blank">
    <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg" />
  </a>
  <a href="https://twitter.com/Leo36363824" target="_blank">
    <img alt="Twitter: Leo36363824" src="https://img.shields.io/twitter/follow/Leo36363824.svg?style=social" />
  </a>
</p>

**English** | [中文](README_zh.md)

> nerd-font-JetBrains-windows

## Install

```sh
git clone https://github.com/runlin-wang/nerd-font-JetBrains-windows.git
```

## Usage

[download](https://github.com/runlin-wang/nerd-font-JetBrains-windows/releases)  
Install these fonts to your Windows system.

## Author

👤 **leo**

* Website: https://runlin.live
* Twitter: [@Leo36363824](https://twitter.com/Leo36363824)
* Github: [@runlin-wang](https://github.com/runlin-wang)

## 🤝 Contributing

Contributions, issues and feature requests are welcome!<br />Feel free to check [issues page](https://github.com/runlin-wang/nerd-font-JetBrains-windows/issues). 

## Show your support

Give a ⭐️ if this project helped you!

## 📝 License

Copyright © 2021 [leo](https://github.com/runlin-wang).<br />
This project is [MIT](LICENSE) licensed.

***
_This README was generated with ❤️ by [readme-md-generator](https://github.com/kefranabg/readme-md-generator)_
